from tkinter import *
from tkinter import filedialog
import pandas as pd
from sklearn.tree import DecisionTreeClassifier # Import Decision Tree Classifier
from sklearn.model_selection import train_test_split # Import train_test_split function
from sklearn import metrics #Import scikit-learn metrics module for accuracy calculation
from sklearn.tree import export_graphviz
from six import StringIO  
from IPython.display import Image  
import pydotplus
from six import StringIO  
from IPython.display import Image  
from sklearn.tree import export_graphviz
import pydotplus


def dia():
    c=Tk()
    c.filename = filedialog.askopenfilename(initialdir="/", title="Select file",
                                                    filetypes=(("CSV", "*.csv"), ("all files", "*.*")))
                                                
    col_names = ['pregnant', 'glucose', 'bp', 'skin', 'insulin', 'bmi', 'pedigree', 'age', 'label']
    # load dataset
    pima = pd.read_csv(c.filename, header=0, names=col_names)
    feature_cols = ['pregnant', 'insulin', 'bmi', 'age','glucose','bp','pedigree']
    X = pima[feature_cols] # Features
    y = pima.label # Target variable
    print(c.filename)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1)
    clf = DecisionTreeClassifier()
    # Train Decision Tree Classifier
    clf = clf.fit(X_train,y_train)
    #Predict the response for test dataset
    y_pred = clf.predict(X_test)
    print("Accuracy:",metrics.accuracy_score(y_test, y_pred))
    dot_data = StringIO()
    export_graphviz(clf, out_file=dot_data,  
                    filled=True, rounded=True,
                    special_characters=True,feature_names = feature_cols,class_names=['0','1'])
    graph = pydotplus.graph_from_dot_data(dot_data.getvalue())  
    #graph.write_png('diabetes.png')
    #Image(graph.create_png())
    #clf = DecisionTreeClassifier(criterion="entropy", max_depth=3)

    # Train Decision Tree Classifier
    #clf = clf.fit(X_train,y_train)

    #Predict the response for test dataset
    y_pred = clf.predict(X_test)

    # Model Accuracy, how often is the classifier correct?
    #print("Accuracy:",metrics.accuracy_score(y_test, y_pred))
    #dot_data = StringIO()
    export_graphviz(clf, out_file=dot_data,
                        filled=True, rounded=True,
                        special_characters=True, feature_names = feature_cols,class_names=['0','1'])
    #graph = pydotplus.graph_from_dot_data(dot_data.getvalue())
    #graph.write_png('diabetes.png')
    #Image(graph.create_png())


    pregnantS = e1.get()
    insS = e4.get()
    bmiS = e5.get()
    ageS = e7.get()
    gluS = e2.get()
    bpS = e3.get()
    pedGree = e6.get()
    feature_cols = ['pregnant', 'insulin', 'bmi', 'age','glucose','bp','pedigree']
    dic= {
        "pregnant":pregnantS,'insulin':insS,'bmi':bmiS,'age':ageS,'glucose':gluS,'bp':bpS ,'pedigree':pedGree
    }
    df=pd.DataFrame(dic, index=['0'])
    pred = clf.predict(df)
    dummy=""
    if(pred==0):
        print("GOOD NEWS CURRENTLY YOU HAVE NO CHANCE OF  DIABETES IN FUTURE")
        dummy = dummy + "GOOD NEWS CURRENTLY YOU HAVE NO CHANCE OF  DIABETES IN FUTURE"
    else:
        print("BE CAREFUL YOU HAVE A CHANCE OF DIABETES IN FUTURE")
        dummy = dummy + "BE CAREFUL YOU HAVE A CHANCE OF DIABETES IN FUTURE"
    z = Tk()
    z.title("Diabetes Prediction")
    z.configure(background="#eb121b")
    Label(z, text=dummy, font="Tw-Cen-MT-Condensed-Extra-Bold 13 bold",bg="#eb121b").grid(row=0, column=1)


a=Tk()
a.title("Diabetes Prediction")
a.configure(background="#53bd93")

Label(a,text="\nDIABETES PREDICTION [DECISION TREE BASED]",font="Tw-Cen-MT-Condensed-Extra-Bold 13 bold",bg="#53bd93").grid(row=0, column=1)
Label(a, text='Pregnacies',bg="#53bd93").grid(row=1)
Label(a, text='Glucose',bg="#53bd93").grid(row=2)
Label(a, text='Bloop Pressure',bg="#53bd93").grid(row=3)
Label(a, text='Insulin',bg="#53bd93").grid(row=4)
Label(a, text='BMI',bg="#53bd93").grid(row=5)
Label(a, text= 'diabetes Pedigree ',bg="#53bd93").grid(row=6)
Label(a, text='Age',bg="#53bd93").grid(row=7)

e1 = Entry(a)
e2 = Entry(a)
e3 = Entry(a)
e4 = Entry(a)
e5 = Entry(a)
e6 = Entry(a)
e6 = Entry(a)
e7 = Entry(a)

e1.grid(row=1, column=1)
e2.grid(row=2, column=1)
e3.grid(row=3, column=1)
e4.grid(row=4, column=1)
e5.grid(row=5, column=1)
e6.grid(row=6, column=1)
e7.grid(row=7, column=1)

Button(a,text="CHOOSE DATA SET & PREDICT",command=dia,height=1,font="Bahnschrift 14 bold",border=0,background="#b57e58",activebackground="black", activeforeground="red",highlightcolor="black").grid(row=9, column=1)

a.mainloop()